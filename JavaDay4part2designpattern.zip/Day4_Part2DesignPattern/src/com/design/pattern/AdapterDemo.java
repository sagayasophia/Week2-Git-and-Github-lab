
package com.design.pattern;

public class AdapterDemo {

    public static void main(String[] args) {
        Notifier notifier = new EmailAdapter(new EmailSDK());
        notifier.notifyUser("sophia", "Your order has been shipped!");
    }
}
