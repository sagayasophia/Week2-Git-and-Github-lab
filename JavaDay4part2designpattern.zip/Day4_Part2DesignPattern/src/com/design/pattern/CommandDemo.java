
package com.design.pattern;

import java.util.ArrayDeque;
import java.util.Deque;

// Command contract
interface Command {
    void execute();
    default void undo() {} // optional
}

// Receiver
class Account {
    private int balance = 0;
    void deposit(int amt) {
        balance += amt;
        System.out.println("Deposit " + amt + " -> balance=" + balance);
    }
    void withdraw(int amt) {
        balance -= amt;
        System.out.println("Withdraw " + amt + " -> balance=" + balance);
    }
}

// Concrete commands
class DepositCommand implements Command {
    private final Account account; private final int amt;
    DepositCommand(Account account, int amt){ this.account = account; this.amt = amt; }
    public void execute(){ account.deposit(amt); }
    public void undo(){ account.withdraw(amt); }
}
class WithdrawCommand implements Command {
    private final Account account; private final int amt;
    WithdrawCommand(Account account, int amt){ this.account = account; this.amt = amt; }
    public void execute(){ account.withdraw(amt); }
    public void undo(){ account.deposit(amt); }
}

// Invoker with history for undo
class CommandBus {
    private final Deque<Command> history = new ArrayDeque<>();
    void submit(Command c){ c.execute(); history.push(c); }
    void undoLast(){
        if (!history.isEmpty()) {
            Command c = history.pop();
            System.out.println("Undoing last command...");
            c.undo();
        }
    }
}

public class CommandDemo {
    public static void main(String[] args) {
        Account account = new Account();
        CommandBus bus = new CommandBus();

        bus.submit(new DepositCommand(account, 100));
        bus.submit(new WithdrawCommand(account, 35));
        bus.submit(new DepositCommand(account, 50));

        // Oops—undo the last action:
        bus.undoLast();
    }
}
