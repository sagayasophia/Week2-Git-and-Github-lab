
package com.design.pattern;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// Component interface
interface ReportService {
    String generate();
}

// Concrete component
class BaseReportService implements ReportService {
    @Override
    public String generate() {
        // Simulate heavy work
        try { Thread.sleep(200); } catch (InterruptedException ignored) {}
        return "BASE-REPORT-" + System.nanoTime();
    }
}

// Decorator (base)
abstract class ReportServiceDecorator implements ReportService {
    protected final ReportService delegate;
    protected ReportServiceDecorator(ReportService delegate) { this.delegate = delegate; }
}

// Concrete decorator #1: logging
class LoggingDecorator extends ReportServiceDecorator {
    LoggingDecorator(ReportService delegate) { super(delegate); }
    @Override
    public String generate() {
        long t0 = System.currentTimeMillis();
        String out = delegate.generate();
        long t1 = System.currentTimeMillis();
        System.out.println("[LOG] generate took " + (t1 - t0) + " ms");
        return out;
    }
}

// Concrete decorator #2: caching (simple demo cache)
class CachingDecorator extends ReportServiceDecorator {
    private final Map<String, String> cache = new ConcurrentHashMap<>();
    CachingDecorator(ReportService delegate) { super(delegate); }
    @Override
    public String generate() {
        // One fixed key for demo; in real cases derive a key from inputs
        return cache.computeIfAbsent("REPORT_KEY", k -> delegate.generate());
    }
}

public class DecoratorDemo {
    public static void main(String[] args) {
        ReportService service =
            new CachingDecorator(
                new LoggingDecorator(
                    new BaseReportService()));

        System.out.println(service.generate()); // first call: logs + computes
        System.out.println(service.generate()); // second call: cache hit (very fast)
    }
}
