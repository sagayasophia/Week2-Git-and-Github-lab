
package com.design.pattern;

public class EmailAdapter implements Notifier {

    private final EmailSDK emailSDK;

    public EmailAdapter(EmailSDK emailSDK) {
        this.emailSDK = emailSDK;
    }

    @Override
    public void notifyUser(String userId, String message) {
        String email = userId + "@example.com"; // userId → email mapping
        emailSDK.sendEmail(email, message);
    }
}
