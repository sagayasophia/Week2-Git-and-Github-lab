
package com.design.pattern;

// Imagine this comes from an external SDK
public class EmailSDK {

    public void sendEmail(String email, String body) {
        System.out.println("Email sent to " + email + " with message: " + body);
    }
}
