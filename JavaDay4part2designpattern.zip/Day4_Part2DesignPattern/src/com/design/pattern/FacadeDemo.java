
package com.design.pattern;

// Subsystems (could be remote HTTP clients in real life)
class PaymentGateway {
    boolean charge(String userId, int amount) {
        System.out.println("Charged " + userId + " amount " + amount);
        return true;
    }
    boolean refund(String userId, int amount) {
        System.out.println("Refunded " + userId + " amount " + amount);
        return true;
    }
}
class InventoryService {
    boolean reserve(String sku, int qty) {
        System.out.println("Reserved " + sku + " x" + qty);
        return true;
    }
    void release(String sku, int qty) {
        System.out.println("Released " + sku + " x" + qty);
    }
}
class ShippingService {
    void ship(String sku, int qty, String userId) {
        System.out.println("Shipped " + sku + " x" + qty + " to " + userId);
    }
}

// Façade that orchestrates the flow
class OrderFacade {
    private final PaymentGateway payment;
    private final InventoryService inventory;
    private final ShippingService shipping;

    OrderFacade(PaymentGateway payment, InventoryService inventory, ShippingService shipping) {
        this.payment = payment; this.inventory = inventory; this.shipping = shipping;
    }

    public boolean placeOrder(String userId, String sku, int qty, int amount) {
        if (!inventory.reserve(sku, qty)) return false;
        if (!payment.charge(userId, amount)) {
            inventory.release(sku, qty);
            return false;
        }
        shipping.ship(sku, qty, userId);
        return true;
    }

    public void cancelOrder(String userId, String sku, int qty, int amount) {
        // Simple demo compensation
        payment.refund(userId, amount);
        inventory.release(sku, qty);
        System.out.println("Order canceled for " + userId);
    }
}

public class FacadeDemo {
    public static void main(String[] args) {
        OrderFacade facade = new OrderFacade(
                new PaymentGateway(),
                new InventoryService(),
                new ShippingService()
        );

        boolean ok = facade.placeOrder("sophia", "BOOK-123", 1, 499);
        System.out.println("Order success: " + ok);

        // Try a cancel path (compensation demo)
        facade.cancelOrder("sophia", "BOOK-123", 1, 499);
    }
}
