
package com.design.pattern;

public interface Notifier {
    void notifyUser(String userId, String message);
}
