/**
 * 
 */
/**
 * 
 */
module Day4_Part2DesignPattern {
}