
# Spring Boot – IoT + AI Fun Case Study (Multi-Layer Architecture)

This project mimics **IoT telemetry**, a tiny **AI anomaly detector**, and fun **media utilities** to keep demos lively:
- `/api/iot/sample` → Generate sensor readings (temperature, humidity, noise)
- `/api/ai/anomaly` → Simple z-score anomaly detection over values
- `/api/media/tone` → Returns a WAV melody you can play in the browser
- `/api/media/badge` → Returns a PNG image badge with a neon robot eye & waveform

## Run
```bash
mvn -q -f spring-boot-iot-ai-fun/pom.xml spring-boot:run
```

## Try it (cURL)
```bash
# 1) IoT sample readings
curl "http://localhost:8080/api/iot/sample?deviceId=cam-1&n=12" | jq .

# 2) AI anomaly detection (last value is a spike)
curl -X POST http://localhost:8080/api/ai/anomaly       -H "Content-Type: application/json"       -d '{"values":[25.1,25.2,25.3,25.0,25.2,31.5]}' | jq .

# 3) Play a melody in your browser
open "http://localhost:8080/api/media/tone?melody=C4-4,D4-4,E4-4,G4-8,E4-8&bpm=120"

# 4) Download a fun badge image
curl -o badge.png "http://localhost:8080/api/media/badge?text=DON%27T+SLEEP+-+QA+ROCKS" && open badge.png
```

## Notes
- **Layers**: controller → service (no DB here; repositories can be added easily)
- **Audio**: generated with Java Sound API (sine wave) and streamed as WAV
- **Image**: drawn with Java2D (BufferedImage) as PNG
- **AI**: very small z-score anomaly detector for demo purposes

Have fun ✨
