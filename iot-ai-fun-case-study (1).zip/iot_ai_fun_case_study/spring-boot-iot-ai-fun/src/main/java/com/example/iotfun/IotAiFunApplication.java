package com.example.iotfun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IotAiFunApplication {
    public static void main(String[] args) {
        SpringApplication.run(IotAiFunApplication.class, args);
    }
}
