package com.example.iotfun.controller;

import com.example.iotfun.dto.InferenceRequest;
import com.example.iotfun.dto.InferenceResponse;
import com.example.iotfun.service.AIService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
public class AIController {
    private final AIService service;
    public AIController(AIService service) { this.service = service; }

    @PostMapping("/anomaly")
    public InferenceResponse anomaly(@Valid @RequestBody InferenceRequest req) {
        return service.simpleAnomaly(req);
    }
}
