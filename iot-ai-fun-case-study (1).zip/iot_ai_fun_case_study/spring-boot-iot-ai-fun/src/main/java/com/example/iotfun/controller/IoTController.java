package com.example.iotfun.controller;

import com.example.iotfun.dto.SensorReading;
import com.example.iotfun.service.IoTService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/iot")
public class IoTController {
    private final IoTService service;
    public IoTController(IoTService service) { this.service = service; }

    @GetMapping("/sample")
    public List<SensorReading> sample(@RequestParam(defaultValue = "dev-1") String deviceId,
                                      @RequestParam(defaultValue = "20") int n) {
        return service.generateReadings(deviceId, Math.max(1, Math.min(n, 200)));
    }
}
