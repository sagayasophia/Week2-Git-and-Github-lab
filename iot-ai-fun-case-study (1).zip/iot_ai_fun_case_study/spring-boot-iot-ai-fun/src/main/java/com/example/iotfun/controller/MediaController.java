package com.example.iotfun.controller;

import com.example.iotfun.service.MediaService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/media")
public class MediaController {
    private final MediaService mediaService;
    public MediaController(MediaService mediaService) { this.mediaService = mediaService; }

    @GetMapping(value="/tone", produces = "audio/wav")
    public ResponseEntity<byte[]> tone(@RequestParam(required=false) String melody,
                                       @RequestParam(defaultValue="120") int bpm) {
        byte[] data = mediaService.tone(melody, bpm);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=melody.wav")
                .contentType(MediaType.parseMediaType("audio/wav"))
                .body(data);
    }

    @GetMapping(value="/badge", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> badge(@RequestParam(required=false) String text,
                                        @RequestParam(required=false) String theme) {
        byte[] png = mediaService.badge(text, theme);
        return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).body(png);
    }
}
