package com.example.iotfun.dto;

import jakarta.validation.constraints.NotNull;
import java.util.List;

public class InferenceRequest {
    @NotNull
    private List<Double> values;

    public InferenceRequest() {}
    public InferenceRequest(List<Double> values) { this.values = values; }
    public List<Double> getValues() { return values; }
    public void setValues(List<Double> values) { this.values = values; }
}
