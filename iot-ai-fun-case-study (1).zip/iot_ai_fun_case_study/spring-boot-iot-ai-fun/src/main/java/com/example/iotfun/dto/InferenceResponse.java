package com.example.iotfun.dto;

public class InferenceResponse {
    private boolean anomaly;
    private double score;
    private double mean;
    private double stddev;

    public InferenceResponse() {}
    public InferenceResponse(boolean anomaly, double score, double mean, double stddev) {
        this.anomaly = anomaly;
        this.score = score;
        this.mean = mean;
        this.stddev = stddev;
    }
    public boolean isAnomaly() { return anomaly; }
    public void setAnomaly(boolean anomaly) { this.anomaly = anomaly; }
    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
    public double getMean() { return mean; }
    public void setMean(double mean) { this.mean = mean; }
    public double getStddev() { return stddev; }
    public void setStddev(double stddev) { this.stddev = stddev; }
}
