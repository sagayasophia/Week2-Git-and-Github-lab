package com.example.iotfun.dto;

import java.time.Instant;

public class SensorReading {
    private String deviceId;
    private Instant timestamp;
    private double temperature;
    private double humidity;
    private double noise;

    public SensorReading() {}
    public SensorReading(String deviceId, Instant timestamp, double temperature, double humidity, double noise) {
        this.deviceId = deviceId;
        this.timestamp = timestamp;
        this.temperature = temperature;
        this.humidity = humidity;
        this.noise = noise;
    }
    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }
    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
    public double getTemperature() { return temperature; }
    public void setTemperature(double temperature) { this.temperature = temperature; }
    public double getHumidity() { return humidity; }
    public void setHumidity(double humidity) { this.humidity = humidity; }
    public double getNoise() { return noise; }
    public void setNoise(double noise) { this.noise = noise; }
}
