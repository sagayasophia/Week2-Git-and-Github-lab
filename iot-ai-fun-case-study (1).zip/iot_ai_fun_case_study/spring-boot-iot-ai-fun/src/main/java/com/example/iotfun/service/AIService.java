package com.example.iotfun.service;

import com.example.iotfun.dto.InferenceRequest;
import com.example.iotfun.dto.InferenceResponse;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AIService {
    public InferenceResponse simpleAnomaly(InferenceRequest req) {
        List<Double> v = req.getValues();
        if (v == null || v.isEmpty()) return new InferenceResponse(false, 0, 0, 0);
        double mean = v.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        double var = v.stream().mapToDouble(x -> (x-mean)*(x-mean)).sum() / v.size();
        double std = Math.sqrt(var);
        double last = v.get(v.size()-1);
        double z = std == 0 ? 0 : Math.abs(last - mean)/std;
        boolean anomaly = z >= 2.5; // threshold
        return new InferenceResponse(anomaly, z, mean, std);
    }
}
