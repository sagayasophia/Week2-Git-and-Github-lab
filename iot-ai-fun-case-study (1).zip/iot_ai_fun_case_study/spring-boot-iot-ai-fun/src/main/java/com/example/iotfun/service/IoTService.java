package com.example.iotfun.service;

import com.example.iotfun.dto.SensorReading;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
public class IoTService {
    public List<SensorReading> generateReadings(String deviceId, int n) {
        if (deviceId == null || deviceId.isBlank()) deviceId = "dev-1";
        Random rnd = new Random(deviceId.hashCode());
        List<SensorReading> list = new ArrayList<>();
        Instant now = Instant.now();
        for (int i = 0; i < n; i++) {
            double baseT = 24 + Math.sin(i/5.0) * 3;
            double baseH = 50 + Math.cos(i/7.0) * 10;
            double baseN = 30 + rnd.nextDouble() * 10;
            double t = baseT + rnd.nextGaussian();
            double h = baseH + rnd.nextGaussian()*2;
            double no = baseN + (i%15==0? rnd.nextDouble()*20 : rnd.nextDouble()*2); // occasional spike
            list.add(new SensorReading(deviceId, now.minusSeconds((n-i)*5L), t, h, no));
        }
        return list;
    }
}
