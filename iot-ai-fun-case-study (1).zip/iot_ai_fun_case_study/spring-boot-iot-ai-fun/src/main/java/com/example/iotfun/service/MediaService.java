package com.example.iotfun.service;

import org.springframework.stereotype.Service;

import javax.sound.sampled.*;
import java.awt.*;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@Service
public class MediaService {
    // Generate a short WAV tone sequence (melody string like "C4-4,D4-4,E4-4")
    public byte[] tone(String melody, int bpm) {
        if (melody == null || melody.isBlank()) melody = "C4-4,D4-4,E4-4,G4-8,E4-8";
        if (bpm <= 0) bpm = 120;
        String[] parts = melody.split(",");
        float sampleRate = 44100f;
        AudioFormat fmt = new AudioFormat(sampleRate, 16, 1, true, false);
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            AudioInputStream total = null;
            for (String p : parts) {
                String[] seg = p.trim().split("-");
                String note = seg[0];
                int dur = seg.length>1? Integer.parseInt(seg[1]) : 4; // quarter by default
                double freq = noteToFreq(note);
                double beatSec = 60.0/bpm;
                double seconds = (4.0/dur)*beatSec;
                byte[] data = synthSine(fmt, seconds, freq, 0.2);
                AudioInputStream ais = new AudioInputStream(new java.io.ByteArrayInputStream(data), fmt, data.length/ fmt.getFrameSize());
                if (total == null) total = ais;
                else total = new AudioInputStream(new java.io.SequenceInputStream(total, ais), fmt, total.getFrameLength()+ais.getFrameLength());
            }
            AudioSystem.write(total, AudioFileFormat.Type.WAVE, baos);
            return baos.toByteArray();
        } catch (Exception e) {
            return new byte[0];
        }
    }

    private byte[] synthSine(AudioFormat fmt, double seconds, double freq, double volume) {
        int frames = (int)(seconds * fmt.getSampleRate());
        byte[] data = new byte[frames * fmt.getFrameSize()];
        double twoPiF = 2*Math.PI*freq;
        for (int i=0;i<frames;i++) {
            double t = i / fmt.getSampleRate();
            double env = Math.min(1, i/(fmt.getSampleRate()*0.02)); // attack 20ms
            env *= Math.min(1, (frames - i)/(fmt.getSampleRate()*0.05)); // release 50ms
            short s = (short)(Math.sin(twoPiF*t) * 32767 * volume * env);
            data[2*i] = (byte)(s & 0xff);
            data[2*i+1] = (byte)((s>>8) & 0xff);
        }
        return data;
    }

    private static final Map<String,Integer> NOTE_INDEX = new HashMap<>();
    static {
        String[] names = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
        for (int o=0;o<=8;o++) {
            for (int i=0;i<names.length;i++) {
                NOTE_INDEX.put(names[i]+o, o*12 + i);
            }
        }
    }
    private double noteToFreq(String token) {
        token = token.toUpperCase(Locale.ROOT).replace("H","B");
        Integer idx = NOTE_INDEX.get(token);
        if (idx == null) idx = NOTE_INDEX.get("A4");
        int n = idx - NOTE_INDEX.get("A4");
        return 440.0 * Math.pow(2, n/12.0);
    }

    // Generate a PNG badge with neon theme + robot eye + waveform
    public byte[] badge(String text, String theme) {
        int w=800,h=360;
        BufferedImage img = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        // Background
        Color bg1 = new Color(12,12,30);
        Color bg2 = new Color(20,20,60);
        g.setPaint(new GradientPaint(0,0,bg1,w,h,bg2));
        g.fillRect(0,0,w,h);
        // Neon frame
        g.setStroke(new BasicStroke(6f));
        g.setColor(new Color(0,255,200,160));
        g.drawRoundRect(10,10,w-20,h-20,30,30);
        // Robot eye
        int cx=120, cy=h/2; int r=60;
        g.setColor(new Color(0,180,255));
        g.fillOval(cx-r, cy-r, 2*r, 2*r);
        g.setColor(Color.black);
        g.fillOval(cx-20, cy-20, 40, 40);
        g.setColor(Color.white);
        g.fillOval(cx-10, cy-10, 20, 20);
        // Waveform line
        Path2D wave = new Path2D.Double();
        int left=220, right=w-40, mid=h/2;
        wave.moveTo(left, mid);
        for (int x=left; x<right; x++) {
            double v = Math.sin((x-left)/18.0) * 35 + Math.sin((x-left)/4.0)*5;
            wave.lineTo(x, mid - v);
        }
        g.setColor(new Color(0,255,170));
        g.setStroke(new BasicStroke(3f));
        g.draw(wave);
        // Text
        if (text==null || text.isBlank()) text = "DON'T SLEEP – CODE. TEST. INNOVATE.";
        g.setFont(new Font("SansSerif", Font.BOLD, 32));
        g.setColor(new Color(230,255,250));
        int tw = g.getFontMetrics().stringWidth(text);
        g.drawString(text, Math.max(left, (w - tw)/2), mid + 110);
        g.dispose();

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            javax.imageio.ImageIO.write(img, "png", baos);
            return baos.toByteArray();
        } catch (IOException e) {
            return new byte[0];
        }
    }
}
